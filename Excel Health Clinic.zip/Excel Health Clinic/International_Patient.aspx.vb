﻿
Partial Class International_Patient
    Inherits System.Web.UI.Page

End Class
