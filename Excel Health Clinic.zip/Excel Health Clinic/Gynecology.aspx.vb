﻿
Partial Class Gynecology
    Inherits System.Web.UI.Page

End Class
