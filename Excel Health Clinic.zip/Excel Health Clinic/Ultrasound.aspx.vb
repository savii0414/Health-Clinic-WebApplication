﻿
Partial Class Ultrasound
    Inherits System.Web.UI.Page

End Class
