﻿
Partial Class Dental
    Inherits System.Web.UI.Page

End Class
