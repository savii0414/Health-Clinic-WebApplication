﻿
Partial Class Physiotherapy
    Inherits System.Web.UI.Page

End Class
