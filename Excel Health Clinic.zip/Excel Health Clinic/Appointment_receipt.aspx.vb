﻿
Partial Class Appointment_receipt
    Inherits System.Web.UI.Page

End Class
