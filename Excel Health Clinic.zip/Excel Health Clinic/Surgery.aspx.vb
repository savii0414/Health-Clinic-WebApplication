﻿
Partial Class Surgery
    Inherits System.Web.UI.Page

End Class
