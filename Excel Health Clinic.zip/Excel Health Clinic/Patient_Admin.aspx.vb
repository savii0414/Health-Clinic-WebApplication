﻿
Partial Class Patient_Admin
    Inherits System.Web.UI.Page

End Class
